<?php 
include 'connection.php';

    if(isset($_POST['submit'])){
        $id 	=	 $_POST['appoint_id'];

        $fetch = "SELECT appoint_date, start_time, end_time from tbl_appointments
        WHERE appointmentID = '$id'";
        $queryrun1 = mysqli_query($conn, $fetch);
        while($date = mysqli_fetch_array($queryrun1)){
            $appointDate = $date['appoint_date'];
            $start = $date['start_time'];
            $end = $date['end_time'];

            $name 	= 	$_POST['name'];
            $purpose 	= 	$_POST['purpose'];
            $insert="INSERT INTO `tbl_transactions`(`appointmentDate`,
            `start_time`, `end_time`, `studentName`, `studentPurpose`)
            VALUES ('$appointDate','$start','$end','$name','$purpose')";
            $query_run2 = mysqli_query($conn,$insert);
            $status = 'Taken';
            $insert2="UPDATE tbl_appointments SET sched_status = '$status'";
            $query_run3 = mysqli_query($conn,$insert2);
            if($query_run2 && $query_run3){
            //$_SESSION['status'] = "Available Sched has been plotted successfully";
                header('location:user_servi.php');
            }
        }
    }
?>