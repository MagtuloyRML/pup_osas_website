<?php 
include 'connection.php';

if(isset($_POST['submit'])){
    $name = $_POST['name'];
    $date = $_POST['date'];
    $time = $_POST['time'];
    $status = $_POST['client_status'];
    $purpose = $_POST['message'];
    $eval = $_POST['eval'];
    $insert = "INSERT INTO `tbl_stud_eval`(`studName`, `date`, `scheduleTime`, `status`,
    `purpose`, `evaluation`)
    VALUES ('$name','$date','$time,''$status'
    ,'$purpose','$eval')";
    $query_run = mysqli_query($conn,$insert);
    if($query_run){
        //$_SESSION['status'] = "Available Sched has been plotted successfully";
        header('location:admin_sched.php');
        }else{
            $_SESSION['status'] = "Available Sched has not been plotted";
            header('location:admin_eval_process.php');
        }

}
?>