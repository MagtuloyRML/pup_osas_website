-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jul 19, 2021 at 02:46 AM
-- Server version: 5.7.31
-- PHP Version: 7.3.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_registration`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_appointments`
--

DROP TABLE IF EXISTS `tbl_appointments`;
CREATE TABLE IF NOT EXISTS `tbl_appointments` (
  `appointmentID` int(11) NOT NULL AUTO_INCREMENT,
  `appoint_date` date NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `sched_urgency` varchar(255) NOT NULL,
  `sched_status` varchar(25) NOT NULL,
  PRIMARY KEY (`appointmentID`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_appointments`
--

INSERT INTO `tbl_appointments` (`appointmentID`, `appoint_date`, `start_time`, `end_time`, `sched_urgency`, `sched_status`) VALUES
(32, '2021-07-20', '00:16:00', '02:16:00', 'Regular', 'Taken');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_login`
--

DROP TABLE IF EXISTS `tbl_login`;
CREATE TABLE IF NOT EXISTS `tbl_login` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `admin_username` varchar(255) NOT NULL,
  `admin_password` varchar(255) NOT NULL,
  `admin_role` varchar(255) NOT NULL,
  `admin_first_name` varchar(255) NOT NULL,
  `admin_middle_name` varchar(255) NOT NULL,
  `admin_last_name` varchar(255) NOT NULL,
  `admin_email` varchar(255) NOT NULL,
  `admin_contact_number` varchar(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_login`
--

INSERT INTO `tbl_login` (`id`, `admin_username`, `admin_password`, `admin_role`, `admin_first_name`, `admin_middle_name`, `admin_last_name`, `admin_email`, `admin_contact_number`) VALUES
(3, 'admin1', 'asdasd', 'Super Admin', 'Test1', 'Test2', 'Test3', 'testing@gmail.com', '09123456789'),
(4, 'admin2', 'asdasd', 'Admin', 'Admin2', 'admin2', 'admi2', 'admin2@gmail.com', '09123456789');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_students`
--

DROP TABLE IF EXISTS `tbl_students`;
CREATE TABLE IF NOT EXISTS `tbl_students` (
  `stud_id` int(11) NOT NULL AUTO_INCREMENT,
  `student_number` varchar(255) NOT NULL,
  `student_password` varchar(255) NOT NULL,
  `student_full_name` varchar(255) NOT NULL,
  `user_role` varchar(11) NOT NULL,
  `student_email` varchar(255) NOT NULL,
  `student_contact_number` varchar(11) NOT NULL,
  `student_guardian_name` varchar(255) NOT NULL,
  `student_guardian_contact_number` varchar(11) NOT NULL,
  PRIMARY KEY (`stud_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_students`
--

INSERT INTO `tbl_students` (`stud_id`, `student_number`, `student_password`, `student_full_name`, `user_role`, `student_email`, `student_contact_number`, `student_guardian_name`, `student_guardian_contact_number`) VALUES
(1, '2018-00154-BN-0', 'asdasd', 'Brian Joshua Pacheca', 'student', 'brianpacheca123@gmail.com', '09123456789', 'Guardian Full Name', '09123456789'),
(5, '2018-00079-BN-0', 'paramore', 'Ermil Magtuloy', 'student', 'ermilmagtuloy1234@gmail.com', '09090909091', 'Mildred Magtuloy', '09080808081'),
(6, '2018-00080-BN-0', 'paramore', 'Kent Abogado', 'student', 'sampleemail@gmail.com', '09070707071', 'Guardian Name', '09060606061');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_stud_appoint_rec`
--

DROP TABLE IF EXISTS `tbl_stud_appoint_rec`;
CREATE TABLE IF NOT EXISTS `tbl_stud_appoint_rec` (
  `appoint_id` int(11) NOT NULL AUTO_INCREMENT,
  `stud_id` int(11) NOT NULL,
  `appointmentID` int(11) NOT NULL,
  `iden_status` varchar(25) NOT NULL,
  `stud_purpose` text NOT NULL,
  PRIMARY KEY (`appoint_id`),
  KEY `stud_id` (`stud_id`),
  KEY `appointmentID` (`appointmentID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_stud_eval`
--

DROP TABLE IF EXISTS `tbl_stud_eval`;
CREATE TABLE IF NOT EXISTS `tbl_stud_eval` (
  `studEvalID` int(11) NOT NULL AUTO_INCREMENT,
  `studName` varchar(255) NOT NULL,
  `date` varchar(255) NOT NULL,
  `scheduleTime` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `purpose` varchar(255) NOT NULL,
  `evaluation` text NOT NULL,
  PRIMARY KEY (`studEvalID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_transactions`
--

DROP TABLE IF EXISTS `tbl_transactions`;
CREATE TABLE IF NOT EXISTS `tbl_transactions` (
  `transactionID` int(11) NOT NULL AUTO_INCREMENT,
  `appointmentDate` date NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `studentName` varchar(255) NOT NULL,
  `studentPurpose` text NOT NULL,
  PRIMARY KEY (`transactionID`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_transactions`
--

INSERT INTO `tbl_transactions` (`transactionID`, `appointmentDate`, `start_time`, `end_time`, `studentName`, `studentPurpose`) VALUES
(17, '2021-07-20', '00:16:00', '02:16:00', 'Brian', 'asdasd');

-- --------------------------------------------------------

--
-- Table structure for table `tb_chart`
--

DROP TABLE IF EXISTS `tb_chart`;
CREATE TABLE IF NOT EXISTS `tb_chart` (
  `stud_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `status` varchar(50) NOT NULL,
  `age` varchar(100) NOT NULL,
  `email` varchar(200) NOT NULL,
  PRIMARY KEY (`stud_id`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_chart`
--

INSERT INTO `tb_chart` (`stud_id`, `name`, `status`, `age`, `email`) VALUES
(1, 'Andrei Guieb', 'student', ' 12', 'andreiguieb@gmail.com'),
(2, 'Brian ', 'alumni', ' 12', 'aaaa@gmail.com'),
(3, 'ralph', 'student', ' 21', 'aaa@gmail.com'),
(4, 'Paulo', 'student', ' 15', 'asasa@gmail.com'),
(5, 'Marvin', 'alumni', ' 21', 'asasa@gmail.com'),
(6, 'ERMIL', 'alumni', ' 22', 'asasa@gmail.com'),
(7, 'ANDRE', 'student', ' 25', 'asasa@gmail.com'),
(8, 'Andrei Guieb', 'student', ' 21', 'andreiguieb@gmail.com'),
(9, 'Andrei Guieb', 'student', ' 12', 'andreiguieb@gmail.com'),
(10, 'Andrei Guieb', 'alumni', ' 23', 'andreiguieb@gmail.com'),
(17, 'ermil', 'alumni', ' 22', 'aaaa@gmail.com'),
(16, 'bri', 'alumni', ' 25', 'aaaa@gmail.com'),
(18, 'ermil m', 'alumni', ' 21', 'aaaa@gmail.com'),
(19, 'Marvin A', 'alumni', ' 22', 'andreiguieb@gmail.com'),
(20, 'Andrei Guieb', 'student', ' 21', 'andreiguieb@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `tb_monitorclient`
--

DROP TABLE IF EXISTS `tb_monitorclient`;
CREATE TABLE IF NOT EXISTS `tb_monitorclient` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_monitorclient`
--

INSERT INTO `tb_monitorclient` (`user_id`, `name`) VALUES
(1, 'Andrei Guieb'),
(2, 'ralph'),
(3, 'Brian '),
(5, 'Paulo'),
(6, 'ermil'),
(7, 'Marvin'),
(8, 'Marvin');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
