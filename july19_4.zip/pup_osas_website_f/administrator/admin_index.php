<?php 
//connect sa db
$connect = mysqli_connect('localhost','root','','try3');
//magbibilang at magseseparate ng status
$query = "SELECT status, count(*) as number FROM tb_chart GROUP BY status";
$result = mysqli_query($connect, $query); 
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>PUPBC OSAS Admin Page</title>
    <link rel="stylesheet" href="css/admin_nav_style.css">
    <link rel="stylesheet" href="css/admin_index.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css"/>
    <script src="https://cdn.jsdelivr.net/npm/chart.js@2.8.0"></script>

    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      google.charts.load("current", {packages:["corechart"]});
      google.charts.setOnLoadCallback(drawChart);
      function drawChart() {
        var data = google.visualization.arrayToDataTable([
          ['Status', 'Number'],
          <?php
            while($row = mysqli_fetch_array($result))
            {
              echo "['".$row["status"]."', ".$row["number"]."],";
            }

          ?>
        ]);

        var options = {
          title: 'Number of Client',
          pieHole: 0.2,
          backgroundColor: 'transparent',
          colors: ['#1b1b1b', '#5f5f5f']
        };

        var chart = new google.visualization.PieChart(document.getElementById('donutchart'));
        chart.draw(data, options);
      }
    </script>

  </head>
  <body>
    <div class="wrapper">
      <input type="checkbox" id="btn" hidden>
      <label for="btn" class="menu-btn">
        <i class="fas fa-bars"></i>
        <i class="fas fa-times"></i>
      </label>
      <nav id="sidebar">
        <div class="title">Menu</div>
        <ul class="list-items">
          <li><a class="active" href="admin_index.php"><i class="fas fa-chart-area"></i>Overview</a></li>
          <li><a href="admin_clients.php"><i class="fas fa-address-book"></i>Clients</a></li>
          <li><a href="admin_acc.php"><i class="fas fa-user"></i>User</a></li>
          <li><a href="admin_notif.php"><i class="fas fa-bell"></i>Notification</a></li>
          <li><a href="admin_sched.php"><i class="fas fa-calendar-day"></i>Available Sched</a></li>
        </ul>
      </nav>
    </div>
    <section class="content">
      <div class="content1">
      <h2>Overview</h2>
      <div class="main__cards">
        <div class="card">
          <i class="fa fa-user fa-2x" aria-hidden="true"></i>
          <div class="card_inner">
            <p class="text-primary-p">Monitor Client</p>
          <!-- Monitoring  Clients --->
          <?php
            $query = "SELECT user_id FROM tb_monitorclient ORDER BY user_id";  
            $query_run = mysqli_query($connect, $query);
            $row = mysqli_num_rows($query_run);
            echo '<span class="font-bold text-title">'.$row.'</span>';
          ?>
          </div>
        </div>

        <div class="card">
          <i class="fa fa-calendar fa-2x" aria-hidden="true"></i>
          <div class="card_inner">
            <p class="text-primary-p">Upcoming Meeting</p>
            <!-- Monitoring  Clients --->
          <?php
            $query = "SELECT user_id FROM tb_monitorclient ORDER BY user_id";  
            $query_run = mysqli_query($connect, $query);
            $row = mysqli_num_rows($query_run);
            echo '<span class="font-bold text-title">'.$row.'</span>';
          ?>
          </div>
        </div>

        <div class="card">
          <i class="fa fa-calendar fa-2x" aria-hidden="true"></i>
          <div class="card_inner">
            <p class="text-primary-p">Upcoming Appointment</p>
            <!-- Monitoring  Clients --->
          <?php
            $query = "SELECT user_id FROM tb_monitorclient ORDER BY user_id";  
            $query_run = mysqli_query($connect, $query);
            $row = mysqli_num_rows($query_run);
            echo '<span class="font-bold text-title">'.$row.'</span>';
          ?>
          </div>
        </div>
        </div>

        <div class="chart">
          <div class="app-transac">
            <div id="donutchart" class="canvas" ></div>
          </div>
          <div class="app-transac">
            <canvas id="myMonthlyApp">
          </div>
        </div>
        <div class="app-transac1">
            <h2>Previous Appoinment</h2>
            <table class="app-td-list">
              <tr class="app-title">
                <th>Student Name</th>
                <th>Student Number</th>
                <th>Appointment Date and Time</th>
                <th>Status</th>
              </tr>
              <tr class="app-td-item">
                <td>Student Name</th>
                <td>Student Number</td>
                <td>Date and Time</th>
                <td>Status</th>
              </tr>
              <tr class="app-td-item">
                <td>Student Name</td>
                <td>Student Number</td>
                <td>Date and Time</td>
                <td>Status</td>
              </tr>
            </table>
          </div>
      </div>

      
    </section>

  <script src="js/chart_index.js"></script>
  
  </body>
</html>
