<?php

include "connection.php"; // Using database connection file here
$appointmentID = $_GET['a_id']; // get id through query string
$query = "DELETE FRom tbl_appointments where appointmentID = '$appointmentID'";

$data=mysqli_query($conn, $query);


if($data)
{
    mysqli_close($conn); // Close connection
    header("location:admin_sched.php"); // redirects to scheduling page
    exit;	
}
else
{
    echo "Error deleting record"; // display error message if not delete
}

?>