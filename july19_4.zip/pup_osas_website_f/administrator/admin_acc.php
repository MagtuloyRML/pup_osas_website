<?php
 
session_start();

  

if (!isset($_SESSION['admin_username'])) {
    header('location: admin_login.php');
}

  
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>PUP OSAS Admin Page</title>
    <link rel="stylesheet" href="css/admin_nav_style.css">
    <link rel="stylesheet" href="css/admin_acc.css">
    <link rel="stylesheet" href="css/logout_modal.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css"/>
  </head>
  <body>
    <div class="wrapper">
      <input type="checkbox" id="btn" hidden>
      <label for="btn" class="menu-btn">
        <i class="fas fa-bars"></i>
        <i class="fas fa-times"></i>
      </label>
      <nav id="sidebar">
        <div class="title">Menu</div>
        <ul class="list-items">
          <li><a href="admin_index.php"><i class="fas fa-chart-area"></i>Overview</a></li>
          <li><a href="admin_clients.php"><i class="fas fa-address-book"></i>Clients</a></li>
          <li><a class="active" href="admin_acc.php"><i class="fas fa-user"></i>User</a></li>
          <li><a href="admin_notif.php"><i class="fas fa-bell"></i>Notification</a></li>
          <li><a href="admin_sched.php"><i class="fas fa-calendar-day"></i>Available Sched</a></li>
        </ul>
      </nav>
    </div>
    <section class="content">
      <form id="studentInfo" action="#">
      <h2>Profile</h2>
      <div class="cont">
      <form>
        <div class="top-box">
		      <?php
            include "connection.php";
			      $username = $_SESSION['admin_username'];
            $sql_statement = $conn->query("SELECT * FROM `tbl_login` WHERE admin_username ='$username'");
		      	while($row = $sql_statement->fetch_array()){
		      ?>
			    <div>
				    <h5>First Name:</h5>
				    <input type="text" id="stud_ID" name="#" placeholder="First Name" value="<?php echo $row ['admin_first_name']; ?> " readonly>
			      </div>
			    <div>
				    <h5>Middle Name:</h5>
				    <input type="text" id="stud_ID" name="#" placeholder="Middle Name" value="<?php echo $row ['admin_middle_name']; ?> " readonly>
			    </div>
          <div>
				    <h5>Last Name:</h5>
				    <input type="text" id="stud_ID" name="#" placeholder="Last Name" value="<?php echo $row ['admin_last_name']; ?> " readonly>
			    </div>
        </div>
        <div class="top-box">
          <div>
				    <h5>Username:</h5>
				    <input type="text" id="stud_ID" name="#" placeholder="Username" value="<?php echo $row ['admin_username']; ?> " readonly>
			    </div>
			    <div>
				    <h5>Email Address:</h5>
				    <input type="text" id="stud_ID" name="#" placeholder="Email Add" value="<?php echo $row ['admin_email']; ?> " readonly>
			    </div>
			    <div>
				    <h5>Contact Number:</h5>
				    <input type="text" id="stud_ID" name="#" placeholder="Contact Number" value="<?php echo $row ['admin_contact_number']; ?> " readonly>
			    </div>
        </div> 
		    <div class="top-box-bttn">
			    <a href="#" class="btn" id="bttnEdit">Edit</a>
			    <a href="#" class="btn" id="bttnLogOut">Log Out</a>
		    </div>
		    <?php
		      }
		    ?>
		  </form>
		</div>
  </section>

    <div id="modalLogOut" class="logOutModal">
      <div class="modalContent">
        <div class="modalHeader">
          <button type="button" class="closeBtn" data-dismiss="modal">&times;</button>
        </div>
        <div class="modalBody">
          <h2>Are you sure you want to Log out?</h2>
        </div>
        <div class="modalFooter">
          <button type="button" class="btn btn-cancel" data-dismiss="modal">No</button>
          <button type="button" class="btn btn-logout" onclick="location.href='admin_login.php';">Yes</button>
        </div>
      </div>
    </div>
  
    <script src="js/modalLogout.js"></script>
    
  </body>
</html>
