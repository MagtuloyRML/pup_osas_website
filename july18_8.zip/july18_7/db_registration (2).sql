-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jul 18, 2021 at 04:23 PM
-- Server version: 5.7.31
-- PHP Version: 7.3.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_registration`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_appointments`
--

DROP TABLE IF EXISTS `tbl_appointments`;
CREATE TABLE IF NOT EXISTS `tbl_appointments` (
  `appointmentID` int(11) NOT NULL AUTO_INCREMENT,
  `appoint_date` varchar(255) NOT NULL,
  `start_time` varchar(255) NOT NULL,
  `end_time` varchar(255) NOT NULL,
  `sched_urgency` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  PRIMARY KEY (`appointmentID`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_appointments`
--

INSERT INTO `tbl_appointments` (`appointmentID`, `appoint_date`, `start_time`, `end_time`, `sched_urgency`, `status`) VALUES
(18, '2021-07-19', '16:40', '17:40', 'Regular', ''),
(19, '2021-07-19', '17:13', '18:14', 'Regular', 'Available');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_login`
--

DROP TABLE IF EXISTS `tbl_login`;
CREATE TABLE IF NOT EXISTS `tbl_login` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `admin_username` varchar(255) NOT NULL,
  `admin_password` varchar(255) NOT NULL,
  `admin_role` varchar(255) NOT NULL,
  `admin_first_name` varchar(255) NOT NULL,
  `admin_middle_name` varchar(255) NOT NULL,
  `admin_last_name` varchar(255) NOT NULL,
  `admin_email` varchar(255) NOT NULL,
  `admin_contact_number` varchar(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_login`
--

INSERT INTO `tbl_login` (`id`, `admin_username`, `admin_password`, `admin_role`, `admin_first_name`, `admin_middle_name`, `admin_last_name`, `admin_email`, `admin_contact_number`) VALUES
(3, 'admin1', 'asdasd', 'Super Admin', 'Test1', 'Test2', 'Test3', 'testing@gmail.com', '09123456789'),
(4, 'admin2', 'asdasd', 'Admin', 'Admin2', 'admin2', 'admi2', 'admin2@gmail.com', '09123456789');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_students`
--

DROP TABLE IF EXISTS `tbl_students`;
CREATE TABLE IF NOT EXISTS `tbl_students` (
  `stud_id` int(11) NOT NULL AUTO_INCREMENT,
  `student_number` varchar(255) NOT NULL,
  `student_password` varchar(255) NOT NULL,
  `student_full_name` varchar(255) NOT NULL,
  `student_email` varchar(255) NOT NULL,
  `student_contact_number` varchar(11) NOT NULL,
  `student_guardian_name` varchar(255) NOT NULL,
  `student_guardian_contact_number` varchar(11) NOT NULL,
  `student_status` varchar(255) NOT NULL,
  PRIMARY KEY (`stud_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_students`
--

INSERT INTO `tbl_students` (`stud_id`, `student_number`, `student_password`, `student_full_name`, `student_email`, `student_contact_number`, `student_guardian_name`, `student_guardian_contact_number`, `student_status`) VALUES
(1, '2018-00154-BN-0', 'asdasd', 'Brian Joshua Pacheca', 'brianpacheca123@gmail.com', '09123456789', 'Guardian Full Name', '09123456789', ''),
(5, '2018-00152-BN-0', 'asdasd', 'Ermil Magtuloy', 'ermil@gmail.com', '09123456789', 'Erma Magtuloy', '09123456789', ''),
(6, '2018-00153-BN-0', 'asdasd', 'Ther Talan', 'ther@gmail.com', '09123456789', 'Therma Talan', '09123456789', 'student');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_transactions`
--

DROP TABLE IF EXISTS `tbl_transactions`;
CREATE TABLE IF NOT EXISTS `tbl_transactions` (
  `transactionID` int(11) NOT NULL AUTO_INCREMENT,
  `appointmentID` int(11) NOT NULL,
  `stud_ID` int(11) NOT NULL,
  PRIMARY KEY (`transactionID`),
  KEY `transaction_student_fr` (`stud_ID`),
  KEY `transaction_appointments_fr` (`appointmentID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_transactions`
--

INSERT INTO `tbl_transactions` (`transactionID`, `appointmentID`, `stud_ID`) VALUES
(1, 18, 1),
(2, 19, 5),
(3, 18, 5),
(4, 19, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_users`
--

DROP TABLE IF EXISTS `tbl_users`;
CREATE TABLE IF NOT EXISTS `tbl_users` (
  `student_num` varchar(25) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `middle_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) NOT NULL,
  `email_add` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `contact_num` int(11) NOT NULL,
  `guardian_name` varchar(255) NOT NULL,
  `guardian_contact_num` int(11) NOT NULL,
  PRIMARY KEY (`student_num`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tb_chart`
--

DROP TABLE IF EXISTS `tb_chart`;
CREATE TABLE IF NOT EXISTS `tb_chart` (
  `stud_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `status` varchar(50) NOT NULL,
  `age` varchar(100) NOT NULL,
  `email` varchar(200) NOT NULL,
  PRIMARY KEY (`stud_id`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_chart`
--

INSERT INTO `tb_chart` (`stud_id`, `name`, `status`, `age`, `email`) VALUES
(1, 'Andrei Guieb', 'student', ' 12', 'andreiguieb@gmail.com'),
(2, 'Brian ', 'alumni', ' 12', 'aaaa@gmail.com'),
(3, 'ralph', 'student', ' 21', 'aaa@gmail.com'),
(4, 'Paulo', 'student', ' 15', 'asasa@gmail.com'),
(5, 'Marvin', 'alumni', ' 21', 'asasa@gmail.com'),
(6, 'ERMIL', 'alumni', ' 22', 'asasa@gmail.com'),
(7, 'ANDRE', 'student', ' 25', 'asasa@gmail.com'),
(8, 'Andrei Guieb', 'student', ' 21', 'andreiguieb@gmail.com'),
(9, 'Andrei Guieb', 'student', ' 12', 'andreiguieb@gmail.com'),
(10, 'Andrei Guieb', 'alumni', ' 23', 'andreiguieb@gmail.com'),
(17, 'ermil', 'alumni', ' 22', 'aaaa@gmail.com'),
(16, 'bri', 'alumni', ' 25', 'aaaa@gmail.com'),
(18, 'ermil m', 'alumni', ' 21', 'aaaa@gmail.com'),
(19, 'Marvin A', 'alumni', ' 22', 'andreiguieb@gmail.com'),
(20, 'Andrei Guieb', 'student', ' 21', 'andreiguieb@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `tb_monitorclient`
--

DROP TABLE IF EXISTS `tb_monitorclient`;
CREATE TABLE IF NOT EXISTS `tb_monitorclient` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_monitorclient`
--

INSERT INTO `tb_monitorclient` (`user_id`, `name`) VALUES
(1, 'Andrei Guieb'),
(2, 'ralph'),
(3, 'Brian '),
(5, 'Paulo'),
(6, 'ermil'),
(7, 'Marvin'),
(8, 'Marvin');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tbl_transactions`
--
ALTER TABLE `tbl_transactions`
  ADD CONSTRAINT `transaction_appointments_fr` FOREIGN KEY (`appointmentID`) REFERENCES `tbl_appointments` (`appointmentID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `transaction_student_fr` FOREIGN KEY (`stud_ID`) REFERENCES `tbl_students` (`stud_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
