<?php
    // for Connection.php
    include 'connection.php';
    //pag sinubmit yung sa admin_signup.php
    if(isset($_POST['submit'])){
        $studnum = $_POST['stud_num'];
        $pass = $_POST['stud_pass'];
        $fullname = $_POST['stud_name'];
        $email = $_POST['stud_email'];
        $contactnumber = $_POST['stud_contactnum'];
        $guardian = $_POST['stud_guardian'];
        $guardiancontactnum = $_POST['stud_guardian_contactnum'];
        $stud_status = $_POST['role'];
        //insert sa database
        $insert="INSERT INTO `tbl_students`(`student_number`, `student_password`,
        `student_full_name`, `student_email`, `student_contact_number`, `student_guardian_name`,
        `student_guardian_contact_number`, `student_status`) VALUES
        ('$studnum','$pass','$fullname','$email',
        '$contactnumber','$guardian','$guardiancontactnum', '$stud_status')";
        if($conn->query($insert)){
            header('location:user_login.php');
            }
    }
?> 