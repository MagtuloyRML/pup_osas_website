<?php
function check_login($conn)
{
	if(isset($_SESSION['stud_id']))
	{
		$id = $_SESSION['stud_id'];
		$query = "SELECT * FROM tbl_students WHERE student_number = '$id' limit 1";

		$result = mysqli_query($conn, $query);
		if($result && mysqli_num_rows($result) > 0)
		{
			$user_data = mysqli_fetch_assoc($result);
			return $user_data;
		}
	}
}