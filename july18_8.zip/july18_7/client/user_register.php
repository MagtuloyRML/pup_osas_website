<?php 
session_start();
include('connection.php');
?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Signup | PUPBC OSAS</title>
    <link rel="stylesheet" href="css/user_reg.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css"/>
  </head>
  <body>
    <div class="container">
      <div class="wrapper">
        <div class="title"><span>Signup</span></div>
        <form method="POST" id ="signup_form" action="user_register_work.php" class="signup_form">
          <div class="row">
            <i class="fas fa-user"></i>
            <input type="text" id="stud_num" name="stud_num" placeholder="Student Number" required>
            <?php
            if(isset($_SESSION["error"])){
              $studnum_error = $_SESSION["error"];
              echo "<span>$studnum_error</span>";
            }
          ?>  
          </div>
          <div class="row">
            <i class="fas fa-user"></i>
            <input type="password" id="stud_pass" name="stud_pass" placeholder="Password" required>
          </div>
          <div class="row">
            <i class="fas fa-user"></i>
            <input type="password" id="stud_pass2" name="stud_pass2" placeholder="Confirm Password" required>
          </div>
          <div class="row">
            <i class="fas fa-user"></i>
            <input type="text" id="stud_name" name="stud_name" placeholder="Full Name" required>
          </div>
          <div class="row">
            <h4>You are?</h4>
            <input type="radio" name="role" class="role" <?php if (isset($gender) && $gender=="female") echo "checked";?> value="student">Student
            <input type="radio" name="role" class="role" <?php if (isset($gender) && $gender=="male") echo "checked";?> value="alumni">Alumni
          </div>
          <div class="row">
            <i class="fas fa-user"></i>
            <input type="text" id="stud_email" name="stud_email" placeholder="Email" required>
            <?php
            if(isset($_SESSION["error"])){
              $email_error = $_SESSION["error"];
              echo "<span>$email_error</span>";
            }
          ?>  
          </div>
          <div class="row">
            <i class="fas fa-user"></i>
            <input type="text" id="stud_contactnum" name="stud_contactnum" placeholder="Contact Number" required>
          </div>
          <div class="row">
            <i class="fas fa-user"></i>
            <input type="text" id="stud_guardian" name="stud_guardian" placeholder="Guardian Full Name" required>
          </div>
          <div class="row">
            <i class="fas fa-user"></i>
            <input type="text" id="stud_guardian_contactnum" name="stud_guardian_contactnum" placeholder="Guardian Contact Number" required>
          </div>
          <div class="row button">
            <input type="submit" id="submit" name="submit" class="form-submit submit" value="Sign Up">
          </div>
        </form>
      </div>
    </div>

  </body>
</html>
