<?php 

    require_once('dateconnection.php');

    function loadDates(){
        $db = new DbConnect;
        $conn = $db->connect();

        $stmt = $conn->prepare("SELECT * FROM tbl_appointments");
        $stmt->execute();
        $dates = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $dates;

    }

?>