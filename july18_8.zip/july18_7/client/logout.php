<?php
	session_start();
	session_unset($_SESSION['stud_id']);
	header('location: user_login.php');
?>