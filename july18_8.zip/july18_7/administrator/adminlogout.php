<?php
	session_start();
	session_unset($_SESSION['stud_id']);
	header('location: admin_login.php');
?>