<?php
session_start();

include("connection.php");
include("adminfunctions.php");

if($_SERVER['REQUEST_METHOD'] == "POST")
{
  //something was posted
  $username = $_POST['uName'];
  $password = $_POST['pass'];

  if(!empty($username) && !empty($password))
  {
    //read from database
    $query = "SELECT * FROM tbl_login WHERE admin_username = '$username' limit 1";

    $result = mysqli_query($conn, $query);



    if($result)
    {
      if($result && mysqli_num_rows($result) > 0)
      {
        $user_data = mysqli_fetch_assoc($result);
        
        if($user_data['admin_password'] == $password)
        {
          $_SESSION['id'] == $user_data['admin_username'];
          header("Location: admin_index.php");
          die;
        }
      }
      echo "<label>Incorrect Username or Password!</label>";
    }else
    {
    echo "<label>Incorrect Username or Password!</label>";
    }

  }
}
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Admin | PUPBC OSAS</title>
    <link rel="stylesheet" href="css/user_login.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css"/>
  </head>
  <body>
    <div class="container">
      <div class="wrapper">
        <div class="title"><span>Login Administrator</span></div>
        <form method="POST" id ="signup_form" class="login_form">
          <div class="row">
            <i class="fas fa-user"></i>
            <input type="text" placeholder="Username" id="uName" name="uName" required>
          </div>
          <div class="row">
            <i class="fas fa-lock"></i>
            <input type="password" placeholder="Password" id="pass" name="pass" required>
          </div>
          <div class="row button">
            <button type="submit" name="submit" id="submit" class="form-submit submit">Log in</button>
          </div>
          <div class="signup-link">Doesn't have Account yet? <a href="admin_signup.php">Signup now</a></div>
        </form>
      </div>
    </div>

  </body>
</html>
