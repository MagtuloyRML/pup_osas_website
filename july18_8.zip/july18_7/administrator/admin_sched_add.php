<?php 
session_start();
include 'connection.php';
date_default_timezone_set("Asia/Singapore");
    if(isset($_POST['submit'])){
        $Date 	=	 $_POST['appoint_date'];
        //$fetch_date = date("M/d/Y", strtotime($Date));
        $StartTime 	= 	$_POST['strt_time'];
        //$s_time = date("g:i:s A", strtotime($StartTime));
        $EndTime 	= 	$_POST['end_time'];
        //$e_time = date("g:i:s A", strtotime($EndTime));
        $urgency    = $_POST['sched_urgency'];

        $insert="INSERT INTO tbl_appointments(appoint_date, start_time, end_time,
        sched_urgency, sched_status) VALUES ('$Date','$StartTime','$EndTime','$urgency','Available')";
        $query_run = mysqli_query($conn,$insert);
        if($query_run){
            //$_SESSION['status'] = "Available Sched has been plotted successfully";
            //header('location:admin_sched.php');
            }else{
                $_SESSION['status'] = "Available Sched has not been plotted";
                header('location:admin_sched.php');
            }

    }
?>