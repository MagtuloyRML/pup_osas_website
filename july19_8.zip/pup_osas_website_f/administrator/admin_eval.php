<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>PUP OSAS Admin Page</title>
    <link rel="stylesheet" href="css/admin_nav_style.css">
    <link rel="stylesheet" href="css/admin_eval.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css"/>
  </head>
  <body>
    <div class="wrapper">
      <input type="checkbox" id="btn" hidden>
      <label for="btn" class="menu-btn">
        <i class="fas fa-bars"></i>
        <i class="fas fa-times"></i>
      </label>
      <nav id="sidebar">
        <div class="title">Menu</div>
        <ul class="list-items">
          <li><a href="admin_index.php"><i class="fas fa-chart-area"></i>Overview</a></li>
          <li><a class="active" href="admin_clients.php"><i class="fas fa-address-book"></i>Clients</a></li>
          <li><a href="admin_acc.php"><i class="fas fa-user"></i>User</a></li>
          <li><a href="admin_notif.php"><i class="fas fa-bell"></i>Notification</a></li>
          <li><a href="admin_sched.php"><i class="fas fa-calendar-day"></i>Available Sched</a></li>
        </ul>
      </nav>
    </div>
    <section class="content">
      <h2 class="title">Evaluation Form</h2>
      <form class="eval" id="eval">
        <div class="cont">
          <div class="top-box">
            <div>
              <h5>Student Number:</h5>
              <input placeholder="Student Number" class="stud_id" type="text" id="stud_id" >
            </div>
            <div>
              <h5>Full Name:</h5>
              <input placeholder="Full Name" class="name" type="text" id="name">
						</div>
            <div>
              <h5>Contact Number:</h5>
              <input placeholder="Contact Number" class="cont_num" type="text" id="cont_num">
			      </div>
          </div>
          <div class="top-box">
            <div>
              <h5>Date</h5>
              <input placeholder="Date" class="prev_date" type="text" id="prev_date">
            </div>
            <div>
              <h5>Schedule Time</h5>
              <input placeholder="Schedule Time" class="prev_time" type="text" id="prev_time">
						</div>
			      <div>
              <h5>Current Status</h5>
              <select placeholder="Status" name="client_status" id="client_status">
                    <option value="1">Need Medical Attention</option>
                    <option value="2">Bad Condition</option>
                    <option value="3">Stable</option>
                    <option value="4">Good Condition</option>
                    <option value="5">Mentaly Good</option>
                  </select>
			      </div>
          </div>
					<div class="top-box-text">
            <div>
              <h5>Purpose in Appointment</h5>
							<textarea name="message" placeholder="Purpose of Appointment" readonly></textarea>
			      </div>
						<div>
              <h5>Evaluation in Appointment</h5>
							<textarea name="message" placeholder="Evaluation of Appointment" ></textarea>
			      </div>
            <div>
              <button type="button" class="btn-prv"><i class="fas fa-caret-left"></i></button>
              <button type="button" class="btn-prv"><i class="fas fa-caret-right"></i></button>
              <button type="button" class="btn-prv"><i class="fas fa-caret-left"></i></button>
              <button type="button" class="btn-prv"><i class="fas fa-caret-right"></i></button>
            </div>
          </div>
		    </div>
        </form>
  </section>

  <!--<script src="js/app_date_time.js"></script>-->
  </body>
</html>
