<?php
session_start();
//error message
$error2 = "Username or Password is incorrect. Please try again";
//This is the connection process, referencing to connection.php
include 'connection.php';
//When the submit button in Login form is clicked
if(isset($_POST['submit'])){
    //giving variable to password and username
    $pass = $_POST['stud_pass'];
    $studnum = $_POST['stud_number'];
    // fetching the data from the database
    $sql_fetch = "SELECT * from tbl_students";
    //giving the result to the system
    $result = $conn->query($sql_fetch);
    //checking if the password and username is matching the database
        while($row = $result->fetch_array()){
            //if the pass and username is correct, display this
            if($row['student_password'] == $pass && $row['student_number'] == $studnum){
                header('location: user_index.php');
            //if the pass and username is INCORRECT, display this
            }else{
                $_SESSION["error2"] = $error2;
                header("location: user_login.php");
            }
        }

}



?>