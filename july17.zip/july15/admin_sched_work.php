<?php 
session_start();
include 'connection.php';
    if(isset($_POST['submit'])){
        
        $Date 	=	 $_POST['appoint_date'];
        $StartTime 	= 	$_POST['strt_time'];
        $EndTime 	= 	$_POST['end_time'];
        $Urgency    = $_POST['sched_urgency'];
        $insert="INSERT INTO tbl_appointments(appoint_date, start_time, end_time,
        sched_urgency) VALUES ('$Date','$StartTime','$EndTime','$Urgency')";
        $query_run = mysqli_query($conn,$insert);
        if($query_run){
            $_SESSION['status'] = "Available Sched has been plotted successfully";
            header('location:admin_sched.php');
            }else{
                $_SESSION['status'] = "Available Sched has not been plotted";
                header('location:admin_sched.php');
            }

    }
?>