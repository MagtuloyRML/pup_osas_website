-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jul 17, 2021 at 02:46 PM
-- Server version: 5.7.31
-- PHP Version: 7.3.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_registration`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_appointments`
--

DROP TABLE IF EXISTS `tbl_appointments`;
CREATE TABLE IF NOT EXISTS `tbl_appointments` (
  `appointmentID` int(11) NOT NULL AUTO_INCREMENT,
  `appoint_date` varchar(255) NOT NULL,
  `start_time` varchar(255) NOT NULL,
  `end_time` varchar(255) NOT NULL,
  `sched_urgency` varchar(255) NOT NULL,
  PRIMARY KEY (`appointmentID`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_appointments`
--

INSERT INTO `tbl_appointments` (`appointmentID`, `appoint_date`, `start_time`, `end_time`, `sched_urgency`) VALUES
(1, '0:00:00 AM', '22:54:00 PM', '23:54:00 PM', 'Regular'),
(2, 'Jul/17/2021', '9:55:00 PM', '10:55:00 PM', 'Regular'),
(3, 'Jul/17/2021', '12:27:00 PM', '1:27:00 AM', 'Regular'),
(4, 'Jul/18/2021', '10:27:00 PM', '11:27:00 PM', 'Regular');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_login`
--

DROP TABLE IF EXISTS `tbl_login`;
CREATE TABLE IF NOT EXISTS `tbl_login` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `admin_username` varchar(255) NOT NULL,
  `admin_password` varchar(255) NOT NULL,
  `admin_role` varchar(255) NOT NULL,
  `admin_first_name` varchar(255) NOT NULL,
  `admin_middle_name` varchar(255) NOT NULL,
  `admin_last_name` varchar(255) NOT NULL,
  `admin_email` varchar(255) NOT NULL,
  `admin_contact_number` varchar(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_login`
--

INSERT INTO `tbl_login` (`id`, `admin_username`, `admin_password`, `admin_role`, `admin_first_name`, `admin_middle_name`, `admin_last_name`, `admin_email`, `admin_contact_number`) VALUES
(3, 'admin1', 'asdasd', 'Super Admin', 'Test1', 'Test2', 'Test3', 'testing@gmail.com', '09123456789'),
(4, 'admin2', 'asdasd', 'Admin', 'Admin2', 'admin2', 'admi2', 'admin2@gmail.com', '09123456789');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_students`
--

DROP TABLE IF EXISTS `tbl_students`;
CREATE TABLE IF NOT EXISTS `tbl_students` (
  `stud_id` int(11) NOT NULL AUTO_INCREMENT,
  `student_number` varchar(255) NOT NULL,
  `student_password` varchar(255) NOT NULL,
  `student_full_name` varchar(255) NOT NULL,
  `student_email` varchar(255) NOT NULL,
  `student_contact_number` varchar(11) NOT NULL,
  `student_guardian_name` varchar(255) NOT NULL,
  `student_guardian_contact_number` varchar(11) NOT NULL,
  PRIMARY KEY (`stud_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_students`
--

INSERT INTO `tbl_students` (`stud_id`, `student_number`, `student_password`, `student_full_name`, `student_email`, `student_contact_number`, `student_guardian_name`, `student_guardian_contact_number`) VALUES
(1, '2018-00154-BN-0', 'asdasd', 'Brian Joshua Pacheca', 'brianpacheca123@gmail.com', '09123456789', 'Guardian Full Name', '09123456789');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
