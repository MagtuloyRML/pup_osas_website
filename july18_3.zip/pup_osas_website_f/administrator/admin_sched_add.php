<?php
    // for Connection.php
    include 'connection.php';
    //pag sinubmit yung sa admin_signup.php
    if(isset($_POST['btn-insert-sched'])){
        $available_time = $_POST['appoint-date'];
        $start_time = $_POST['strt_time'];
        $end_time = $_POST['end_time'];
        $status = $_POST['sched_urgency'];

        //insert sa database
        $insert="INSERT INTO `available_sched` (`appoint-date`, `strt_time`, `end_time`,
        `sched_urgency`)
        VALUES (`$available_time`,`$start_time`,`$end_time`,`$status`)";
        if($conn->query($insert)){
            header('location:admin_login.php');
            }
    }
?> 