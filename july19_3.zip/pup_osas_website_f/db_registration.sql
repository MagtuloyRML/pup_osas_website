-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jul 18, 2021 at 04:56 PM
-- Server version: 8.0.21
-- PHP Version: 7.3.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_registration`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_appointments`
--

DROP TABLE IF EXISTS `tbl_appointments`;
CREATE TABLE IF NOT EXISTS `tbl_appointments` (
  `appointmentID` int NOT NULL AUTO_INCREMENT,
  `appoint_date` date NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `sched_urgency` varchar(255) NOT NULL,
  `sched_status` varchar(25) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`appointmentID`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_appointments`
--

INSERT INTO `tbl_appointments` (`appointmentID`, `appoint_date`, `start_time`, `end_time`, `sched_urgency`, `sched_status`) VALUES
(12, '2021-07-20', '16:13:00', '17:13:00', 'Regular', 'Available');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_login`
--

DROP TABLE IF EXISTS `tbl_login`;
CREATE TABLE IF NOT EXISTS `tbl_login` (
  `id` int NOT NULL AUTO_INCREMENT,
  `admin_username` varchar(255) NOT NULL,
  `admin_password` varchar(255) NOT NULL,
  `admin_role` varchar(255) NOT NULL,
  `admin_first_name` varchar(255) NOT NULL,
  `admin_middle_name` varchar(255) NOT NULL,
  `admin_last_name` varchar(255) NOT NULL,
  `admin_email` varchar(255) NOT NULL,
  `admin_contact_number` varchar(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_login`
--

INSERT INTO `tbl_login` (`id`, `admin_username`, `admin_password`, `admin_role`, `admin_first_name`, `admin_middle_name`, `admin_last_name`, `admin_email`, `admin_contact_number`) VALUES
(3, 'admin1', 'asdasd', 'Super Admin', 'Test1', 'Test2', 'Test3', 'testing@gmail.com', '09123456789'),
(4, 'admin2', 'asdasd', 'Admin', 'Admin2', 'admin2', 'admi2', 'admin2@gmail.com', '09123456789');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_students`
--

DROP TABLE IF EXISTS `tbl_students`;
CREATE TABLE IF NOT EXISTS `tbl_students` (
  `stud_id` int NOT NULL AUTO_INCREMENT,
  `student_number` varchar(255) NOT NULL,
  `student_password` varchar(255) NOT NULL,
  `student_full_name` varchar(255) NOT NULL,
  `user_role` varchar(11) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `student_email` varchar(255) NOT NULL,
  `student_contact_number` varchar(11) NOT NULL,
  `student_guardian_name` varchar(255) NOT NULL,
  `student_guardian_contact_number` varchar(11) NOT NULL,
  PRIMARY KEY (`stud_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_students`
--

INSERT INTO `tbl_students` (`stud_id`, `student_number`, `student_password`, `student_full_name`, `user_role`, `student_email`, `student_contact_number`, `student_guardian_name`, `student_guardian_contact_number`) VALUES
(1, '2018-00154-BN-0', 'asdasd', 'Brian Joshua Pacheca', 'student', 'brianpacheca123@gmail.com', '09123456789', 'Guardian Full Name', '09123456789'),
(5, '2018-00079-BN-0', 'paramore', 'Ermil Magtuloy', 'student', 'ermilmagtuloy1234@gmail.com', '09090909091', 'Mildred Magtuloy', '09080808081'),
(6, '2018-00080-BN-0', 'paramore', 'Kent Abogado', 'student', 'sampleemail@gmail.com', '09070707071', 'Guardian Name', '09060606061');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_stud_appoint_rec`
--

DROP TABLE IF EXISTS `tbl_stud_appoint_rec`;
CREATE TABLE IF NOT EXISTS `tbl_stud_appoint_rec` (
  `appoint_sched_ID` int NOT NULL AUTO_INCREMENT,
  `stud_id` int NOT NULL,
  `appointmentID` int NOT NULL,
  `sched_purpose` text NOT NULL,
  `iden_status` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`appoint_sched_ID`),
  KEY `stud_id` (`stud_id`),
  KEY `appointmentID` (`appointmentID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tbl_stud_appoint_rec`
--
ALTER TABLE `tbl_stud_appoint_rec`
  ADD CONSTRAINT `tbl_stud_appoint_rec_appointID` FOREIGN KEY (`appointmentID`) REFERENCES `tbl_appointments` (`appointmentID`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `tbl_stud_appoint_rec_stud_id` FOREIGN KEY (`stud_id`) REFERENCES `tbl_students` (`stud_id`) ON DELETE RESTRICT ON UPDATE RESTRICT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
