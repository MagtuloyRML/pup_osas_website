<?php
    // for Connection.php
    include 'connection.php';
    //pag sinubmit yung sa admin_signup.php
    if(isset($_POST['submit'])){
        $studnum = $_POST['stud_num'];
        $pass = $_POST['stud_pass'];
        $fullname = $_POST['stud_name'];
        $role = $_POST['role'];
        $email = $_POST['stud_email'];
        $contactnumber = $_POST['stud_contactnum'];
        $guardian = $_POST['stud_guardian'];
        $guardiancontactnum = $_POST['stud_guardian_contactnum'];
        //insert sa database
        $insert="INSERT INTO `tbl_students`(`student_number`, `student_password`,
        `student_full_name`, `user_role`, `student_email`, `student_contact_number`, `student_guardian_name`,
        `student_guardian_contact_number`) VALUES
        ('$studnum','$pass','$fullname','$role','$email',
        '$contactnumber','$guardian','$guardiancontactnum')";
        if($conn->query($insert)){
            header('location:user_login.php');
            }
    }
?> 